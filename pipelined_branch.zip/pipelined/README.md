# Pipelined Implementation
Use this folder to house the implementation of the pipelined RISC V processor
- put all module files into a folder called `src` and have the main wrapper file as `main.v` 

